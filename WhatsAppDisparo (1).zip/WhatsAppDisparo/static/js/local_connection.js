/**
 * Script para ajudar na conexão local com a Evolution API
 */

// Verificar status da conexão com Evolution API local
function checkLocalEvolutionApiStatus() {
    const statusElement = document.getElementById('evolutionApiStatusIndicator');
    
    if (!statusElement) return;
    
    // Se estamos em um ambiente de produção (não localhost), mostrar aviso
    if (!isLocalEnvironment()) {
        statusElement.innerHTML = `
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>Ambiente remoto detectado!</strong> 
                Este sistema precisa ser executado no mesmo ambiente (localhost) onde a Evolution API está instalada.
                <a href="/static/docs/local_setup.html" class="alert-link">Veja as instruções para execução local</a>.
            </div>
        `;
        return;
    }
    
    // Verificar status da Evolution API no localhost
    fetch('/api/evolution/status')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                statusElement.innerHTML = `
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i>
                        <strong>API Local Detectada!</strong> 
                        A conexão com a Evolution API está configurada corretamente.
                    </div>
                `;
            } else {
                statusElement.innerHTML = `
                    <div class="alert alert-danger">
                        <i class="fas fa-times-circle me-2"></i>
                        <strong>API Local Não Detectada!</strong> 
                        Verifique se a Evolution API está rodando localmente e configure a URL correta.
                        <a href="/static/docs/troubleshooting.html" class="alert-link">Ver instruções</a>
                    </div>
                `;
            }
        })
        .catch(error => {
            statusElement.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-times-circle me-2"></i>
                    <strong>Erro de Conexão!</strong> 
                    Não foi possível verificar o status da Evolution API.
                    <a href="/static/docs/troubleshooting.html" class="alert-link">Ver instruções</a>
                </div>
            `;
            console.error("Erro ao verificar status da API:", error);
        });
}

// Verifica se estamos em um ambiente local
function isLocalEnvironment() {
    const hostname = window.location.hostname;
    return hostname === 'localhost' || 
           hostname === '127.0.0.1' ||
           hostname.startsWith('192.168.') || 
           hostname.startsWith('10.') ||
           hostname.endsWith('.local');
}

// Executa quando o documento estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    // Verificar status da Evolution API
    checkLocalEvolutionApiStatus();
    
    // Adicionar aviso de ambiente nas páginas relevantes
    addEnvironmentBanner();
});

// Adiciona banner de ambiente
function addEnvironmentBanner() {
    const banner = document.createElement('div');
    banner.className = 'environment-banner';
    
    if (!isLocalEnvironment()) {
        banner.innerHTML = `
            <div class="alert alert-warning mb-0 text-center py-1">
                <small>
                    <i class="fas fa-cloud me-1"></i>
                    <strong>Ambiente remoto detectado!</strong> 
                    A conexão com Evolution API requer execução local.
                    <a href="/static/docs/local_setup.html" class="alert-link">Ver instruções</a>
                </small>
            </div>
        `;
        
        // Adicionar ao topo da página
        document.body.insertBefore(banner, document.body.firstChild);
    }
}